//
//  QualityTableViewCell.swift
//  MyClip
//
//  Created by Quang Ly Hoang on 9/11/17.
//  Copyright © 2017 Huy Nguyen. All rights reserved.
//

import UIKit

class QualityTableViewCell: UITableViewCell {

    @IBOutlet weak var qualityLabel: UILabel!

}
