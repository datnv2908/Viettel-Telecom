//
//  RelateVideoHeaderModel.swift
//  MyClip
//
//  Created by hnc on 10/7/17.
//  Copyright © 2017 Huy Nguyen. All rights reserved.
//

import Foundation
struct RelateVideoHeaderModel: PBaseHeaderModel {
    var title: String
    var identifier: String?
    var isAutoPlay: Bool
}
