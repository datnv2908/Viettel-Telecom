//
//  KeywordTableViewCell.swift
//  MyClip
//
//  Created by Os on 9/26/17.
//  Copyright © 2017 Huy Nguyen. All rights reserved.
//

import UIKit

class KeywordTableViewCell: BaseTableViewCell {
    
}
