//
//  TabPagerCollectionViewCell.swift
//  MyClip
//
//  Created by Os on 8/28/17.
//  Copyright © 2017 Huy Nguyen. All rights reserved.
//

import UIKit

class TabPagerCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
