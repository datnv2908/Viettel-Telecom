
//
//  HomeItemViewModel.swift
//  MyClip
//
//  Created by Os on 8/29/17.
//  Copyright © 2017 Huy Nguyen. All rights reserved.
//

import UIKit

class HomeItemViewModel: NSObject {
    var data: [VideoRowModel]
    
    override init() {
        data = [VideoRowModel]()
    }
}
