//
//  HomeContainerViewController.swift
//  MyClip
//
//  Created by Huy Nguyen on 8/18/17.
//  Copyright © 2017 GEM. All rights reserved.
//

import UIKit

class HomeContainerViewController: BaseViewController {

    override func viewDidLoad() {

    }

    override func setupView() {

    }
}
