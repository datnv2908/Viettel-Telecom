//
//  VideoCollectionViewCell.swift
//  MyClip
//
//  Created by Os on 8/31/17.
//  Copyright © 2017 Huy Nguyen. All rights reserved.
//

import UIKit

class VideoCollectionViewCell: BaseCollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var timeLabel: UILabel!
    
}
